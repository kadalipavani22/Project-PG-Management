package p1;
import java.util.Scanner;
class A
{
	public Scanner sc=new Scanner(System.in);
	public String b=sc.next();
	public int m2(String s)
	{
		System.out.println(s);
		return sc.nextInt();
	}
	A(String s)
	{
		System.out.println("parameterised constructor");
		System.out.println(s);

	}
	public static void main(String [] args)
	{

		A obj=new A(sc.next());
		System.out.println(obj.b);
		System.out.println(obj.m2(sc.next()));

	}
}