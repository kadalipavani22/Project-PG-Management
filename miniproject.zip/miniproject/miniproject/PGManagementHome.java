import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class PGManagementHome extends JFrame {
    private String loggedInEmail;
    private String loggedInPassword;

    public PGManagementHome(String email, String password) {
        this.loggedInEmail = email;
        this.loggedInPassword = password;

        setTitle("PG Management Home");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        setLocationRelativeTo(null);
        
        // Welcome label
        JLabel welcomeLabel = new JLabel("Welcome to PG Management. We are serving better environment and hostel facilities.", JLabel.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 18));
        welcomeLabel.setForeground(new Color(138, 43, 226)); // Violet color
        welcomeLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0)); // Two-line space
        add(welcomeLabel, BorderLayout.NORTH);
        
        // Panel for buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(6, 1, 10, 10)); // Adjusted for 6 buttons
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 450, 20, 450)); // Space around buttons
        
        Font buttonFont = new Font("Arial", Font.BOLD, 14);
        Dimension buttonSize = new Dimension(200, 40);
        
        JButton citiesButton = new JButton("Display Cities");
        JButton bookingButton = new JButton("PGBookingPage");
        JButton profileButton = new JButton("Profile");
        JButton adminButton = new JButton("Admin Panel"); 
        JButton logoutButton = new JButton("Logout");
        
        JButton[] buttons = {citiesButton, bookingButton, profileButton, adminButton, logoutButton};
        
        for (JButton button : buttons) {
            button.setFont(buttonFont);
            button.setBackground(new Color(173, 216, 230)); // Light cyan color
            button.setPreferredSize(buttonSize);
            buttonPanel.add(button);
        }
        
        add(buttonPanel, BorderLayout.CENTER);
        
        // Add action listeners
        citiesButton.addActionListener(new ButtonActionListener("DisplayCitiesFrame"));
        bookingButton.addActionListener(new ButtonActionListener("PGBookingPage"));
        adminButton.addActionListener(new ButtonActionListener("AdminPanel")); 
        logoutButton.addActionListener(e -> System.exit(0));

        // ✅ Open Profile with correct user details
        profileButton.addActionListener(e -> new Profile(loggedInEmail, loggedInPassword));

        setVisible(true);
    }
    
    public static void main(String[] args) {
        new PGManagementHome("test@gmail.com", "password123"); // Example test
    }
}

class ButtonActionListener implements ActionListener {
    private String frameName;

    public ButtonActionListener(String frameName) {
        this.frameName = frameName;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            Class<?> clazz = Class.forName(frameName);
            JFrame frame = (JFrame) clazz.getDeclaredConstructor().newInstance();
            frame.setVisible(true);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
