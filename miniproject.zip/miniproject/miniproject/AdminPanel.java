import java.awt.*;
import java.io.*;
import javax.swing.*;

public class AdminPanel extends JFrame {
    private JTextField pgNameField, addressField, vacanciesField, priceField, foodMenuField;
    private JComboBox<String> genderBox;
    private JButton addButton, displayButton;
    private JTextArea displayArea;
    private static final String FILE_NAME = "pg_data.txt"; // Persistent storage

    public AdminPanel() {
        setTitle("Admin Panel - Manage PGs");
        setExtendedState(JFrame.MAXIMIZED_BOTH); // Open in full-screen mode
        setLayout(new BorderLayout());
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Create input panel with compact layout
        JPanel inputPanel = new JPanel(new GridLayout(7, 2, 5, 5));
        inputPanel.setBorder(BorderFactory.createTitledBorder("Add PG Details"));

        genderBox = new JComboBox<>(new String[]{"Boys", "Girls"});
        pgNameField = new JTextField();
        addressField = new JTextField();
        vacanciesField = new JTextField();
        foodMenuField = new JTextField();
        priceField = new JTextField();
        addButton = new JButton("Add PG");
        displayButton = new JButton("Display All PGs");

        inputPanel.add(new JLabel("Gender:"));
        inputPanel.add(genderBox);
        inputPanel.add(new JLabel("PG Name:"));
        inputPanel.add(pgNameField);
        inputPanel.add(new JLabel("Address:"));
        inputPanel.add(addressField);
        inputPanel.add(new JLabel("Vacancies:"));
        inputPanel.add(vacanciesField);
        inputPanel.add(new JLabel("Food Menu:"));
        inputPanel.add(foodMenuField);
        inputPanel.add(new JLabel("Room Price:"));
        inputPanel.add(priceField);
        inputPanel.add(addButton);
        inputPanel.add(displayButton);

        // Display area for PG details
        displayArea = new JTextArea();
        displayArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(displayArea);

        add(inputPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        addButton.addActionListener(e -> addPGDetails());
        displayButton.addActionListener(e -> displayPGs());

        setVisible(true);
    }

    private void addPGDetails() {
        String gender = genderBox.getSelectedItem().toString();
        String pgName = pgNameField.getText().trim();
        String address = addressField.getText().trim();
        String vacancies = vacanciesField.getText().trim();
        String foodMenu = foodMenuField.getText().trim();
        String price = priceField.getText().trim();

        if (pgName.isEmpty() || address.isEmpty() || vacancies.isEmpty() || foodMenu.isEmpty() || price.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String pgDetails = gender + "," + pgName + "," + address + "," + vacancies + "," + foodMenu + "," + price + "\n";

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME, true))) {
            writer.write(pgDetails);
            JOptionPane.showMessageDialog(this, "PG Added Successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving PG details!", "Error", JOptionPane.ERROR_MESSAGE);
        }

        pgNameField.setText("");
        addressField.setText("");
        vacanciesField.setText("");
        foodMenuField.setText("");
        priceField.setText("");
    }

    private void displayPGs() {
        displayArea.setText(""); // Clear previous content

        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length == 6) {
                    displayArea.append("Gender: " + data[0] + "\n");
                    displayArea.append("PG Name: " + data[1] + "\n");
                    displayArea.append("Address: " + data[2] + "\n");
                    displayArea.append("Vacancies: " + data[3] + "\n");
                    displayArea.append("Food Menu: " + data[4] + "\n");
                    displayArea.append("Price: ₹" + data[5] + "\n");
                    displayArea.append("----------------------------\n");
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error loading PG data!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        new AdminPanel();
    }
}
