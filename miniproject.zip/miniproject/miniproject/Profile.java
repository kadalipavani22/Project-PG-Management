import java.awt.*;
import java.io.*;
import javax.swing.*;

public class Profile extends JFrame {
    private String email;
    private String username;
    private String city;
    private JTextField cityField;
    private static final String FILE_NAME = "users.txt";

    public Profile(String loggedInEmail, String loggedInPassword) {
        if (!loadUserData(loggedInEmail, loggedInPassword)) {
            JOptionPane.showMessageDialog(null, "Invalid login credentials!", "Login Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        setTitle("User Profile");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());
        setLocationRelativeTo(null);

        // Main Panel
        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = GridBagConstraints.RELATIVE;

        // Welcome Label
        JLabel welcomeLabel = new JLabel("Welcome, " + username + " (" + email + ")", JLabel.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 28));
        welcomeLabel.setForeground(new Color(128, 0, 128));
        panel.add(welcomeLabel, gbc);

        // City Label
        JLabel cityLabel = new JLabel("City:");
        cityLabel.setFont(new Font("Arial", Font.BOLD, 20));
        panel.add(cityLabel, gbc);

        // City Text Field
        cityField = new JTextField(20);
        cityField.setFont(new Font("Arial", Font.PLAIN, 18));
        cityField.setText(city);
        panel.add(cityField, gbc);

        // Update Button
        JButton updateButton = new JButton("Update City");
        updateButton.setFont(new Font("Arial", Font.BOLD, 18));
        updateButton.addActionListener(e -> updateCity());
        panel.add(updateButton, gbc);

        add(panel, BorderLayout.CENTER);
        setVisible(true);
    }

    private boolean loadUserData(String loggedInEmail, String loggedInPassword) {
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 3 && parts[0].equals(loggedInEmail) && parts[1].equals(loggedInPassword)) {
                    this.email = parts[0];
                    this.username = parts[2];
                    this.city = (parts.length >= 4) ? parts[3] : ""; // Default to empty if city is missing
                    return true;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    private void updateCity() {
        String newCity = cityField.getText().trim();
        if (newCity.isEmpty()) {
            JOptionPane.showMessageDialog(this, "City cannot be empty!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            File file = new File(FILE_NAME);
            File tempFile = new File("temp.txt");
            BufferedReader reader = new BufferedReader(new FileReader(file));
            BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));

            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 3 && parts[0].equals(email)) {
                    writer.write(email + "," + parts[1] + "," + username + "," + newCity);
                } else {
                    writer.write(line);
                }
                writer.newLine();
            }

            reader.close();
            writer.close();

            file.delete();
            tempFile.renameTo(file);

            city = newCity;
            JOptionPane.showMessageDialog(this, "City updated successfully!");
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error updating city!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        new Profile("pavani@gmail.com", "4321");
    }
}
